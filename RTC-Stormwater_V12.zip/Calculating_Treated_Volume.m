% Calculating the Treated Volume of Water

Watershed_Flow = Qout_w;
Reservoir_Flow = out_r_final;
time_data = time_plot*86400;

