Welcome to RTC-Stormwater_V12

If you have any questions, please contact me at:

marcusnobrega.engcivil@gmail.com.

You will need the topotoolbox tool, which can be downloaded at:

https://topotoolbox.wordpress.com/download/

You will also need rasters of the digital elevation model, land use and land cover, and soil texture, all of them in the same resolution and extent.

All input data is entered in a excel file attached in this zipped file.

You need to enter the directories of the rasters and of the topotoolbox insider of the excel file.

Do not change the names of the books in the excel sheet.

For mathematical reference, please refer to:

https://doi.org/10.1061/(ASCE)WR.1943-5452.0001588

Thank you,

Marcus Nobrega, Ph.D.

